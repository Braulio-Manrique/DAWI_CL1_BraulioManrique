package pe.Cibertec.DAWI_CL1_Braulio_Manrique;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DawiCl1BraulioManriqueApplicationTests {

	@Test
	void contextLoads() {
	}

}
