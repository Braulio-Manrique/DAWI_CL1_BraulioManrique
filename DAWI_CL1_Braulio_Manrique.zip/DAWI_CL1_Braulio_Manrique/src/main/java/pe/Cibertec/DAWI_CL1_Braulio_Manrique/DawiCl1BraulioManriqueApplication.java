package pe.Cibertec.DAWI_CL1_Braulio_Manrique;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DawiCl1BraulioManriqueApplication {

	public static void main(String[] args) {
		SpringApplication.run(DawiCl1BraulioManriqueApplication.class, args);
	}

}
